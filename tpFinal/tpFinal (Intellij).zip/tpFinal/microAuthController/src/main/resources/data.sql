INSERT INTO `user` (`id`, `apellido`, `email`, `nombre`, `password`, `role`) VALUES
(1, 'System', 'System@system', 'System', '$2a$10$WOqwSe3/fDXLUgoNuamQa.AesQ/JDnkNeyvxnyEM.tvO1h/CbKnPm', 'ADMIN'),
(2, 'Troilo', 'anibal@troilo.com', 'Anibal', '$2a$10$tXIN31WCGW0w8M/DwwWJjO2rPRlcoK4SmpJYDkvWfd1VpORiJPsPK', 'ADMIN'),
(3, 'Argento', 'pepe@argento.com', 'Pepe', '$2a$10$yd6yltUFqmBATH1b4Gi1UuMkWLs7RdstUVVlYpjQLvyj46L2W5PnW', 'MAINTENER'),
(4, 'Pintos', 'abel@pintos.com', 'Abel', '$2a$10$c/6yRbA5UrdFCB2WxrZPzuYXSQxBlQxjz9du0wdatHdvuJj4cV2Da', 'MAINTENER'),
(5, 'Casas', 'armando@casas.com', 'Armando', '$2a$10$jJLKLRhZV.eFR95z.P1HQ.kmf5u9HCMgJtIt/mZa2JgY6Nvf3ycU2', 'MAINTENER'),
(6, 'De Arco', 'juana@dearco.com', 'Juana', '$2a$10$1T60RzAcofo9HNil5o.BROeBy3SLW/eCfExm6TjNAJ1SQLFOCzV6i', 'ADMIN');