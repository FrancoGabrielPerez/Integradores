package com.microuseraccount;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroUserAccountApplicationTests {

    @Test
    void contextLoads() {
    }

}
