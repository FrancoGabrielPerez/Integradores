package com.microuseraccount.service;

import org.springframework.stereotype.Service;

/**
 * UserAccountService
 * 
 * Servicio de la entidad UserAccount.
 * @Author Franco Perez, Luciano Melluso, Lautaro Liuzzi, Ruben Marchiori
 */
@Service("userAccountService")
public class UserAccountService{
    	
}
